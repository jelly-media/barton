<header id="top" class="modula-header">
	<h1 class="header center-on-small-only"><?php esc_html__( 'Modula', 'modula-gallery' ); ?></h1>
	<h4 class="light  text-lighten-4 center-on-small-only"><?php print $tg_subtitle ?></h4>
</header>