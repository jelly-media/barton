<?php
$tg_subtitle = "Tutorial";
include( "header.php" );
?>
<div class='wrap'>
	<?php include( "adv.php" ) ?>
	<h2><?php echo esc_html__( 'Modula - Video tutorial', 'modula-gallery' ); ?></h2><br> <br>
	<iframe width="853" height="480" src="//www.youtube.com/embed/n3EoeY3m7ac?rel=0" frameborder="0" allowfullscreen></iframe>
</div>
